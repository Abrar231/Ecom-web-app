package com.ddmart.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ddmart.model.Category;

public interface CategoryRepo  extends JpaRepository<Category, Long> {

}

