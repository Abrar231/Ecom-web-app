package com.ddmart.service.UserService;

import java.util.HashMap;

import org.springframework.stereotype.Service;

import com.ddmart.model.User;

@Service
public interface UserService {
	User findByMobile(String mobile) throws Exception;
	static User getUserDetailById(long userId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	User signUpUser(HashMap<String,String> signupRequest) throws Exception;
	
}
