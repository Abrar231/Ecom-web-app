import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PageRoutingModule } from './page-routing.module';
import { MainPageComponent } from './main-page/main-page.component';
import { SearchResultComponent } from './search-result/search-result.component';
import { CartComponent } from './cart/cart.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { CategoryCardComponent } from './main-page/category-card/category-card.component';
import { ProductCardComponent } from './search-result/product-card/product-card.component';
import { CartProductCardComponent } from './cart/cart-product-card/cart-product-card.component';

@NgModule({
  declarations: [
    MainPageComponent,
    SearchResultComponent,
    CartComponent,
    LoginPageComponent,
    CategoryCardComponent,
    ProductCardComponent,
    CartProductCardComponent
  ],
  imports: [
    CommonModule,
    PageRoutingModule
  ]
})
export class PageModule { }
