import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {

  constructor(private router: Router) { }

  logIn(){
    window.alert("Logged in.");
    window.alert("Checkout Completed. Your order has been confirmed");
    this.router.navigate(['/home']);
  }

  ngOnInit(): void {
  }

}
