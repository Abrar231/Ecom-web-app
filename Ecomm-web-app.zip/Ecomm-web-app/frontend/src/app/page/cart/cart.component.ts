import { Component, OnInit } from '@angular/core';
import { PageService } from 'src/app/page.service';
import { Product } from 'src/app/product.model';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  cartProducts!: Product[];

  constructor(private pageService: PageService) { }

  getCartProducts(){
    this.pageService.getProductsFromCart().subscribe(products => this.cartProducts = products);
  }

  ngOnInit(): void {
    this.getCartProducts();
  }

}
