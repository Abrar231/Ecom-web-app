import { Component, Input, OnInit } from '@angular/core';
import { PageService } from 'src/app/page.service';
import { Product } from 'src/app/product.model';

@Component({
  selector: 'app-product-card',
  templateUrl: './product-card.component.html',
  styleUrls: ['./product-card.component.css']
})
export class ProductCardComponent implements OnInit {

  @Input() product!: Product;

  addToCart(product: Product){
    window.alert('Item added to Cart');
    this.pageService.addtoCart(product).subscribe(product => this.product = product);
  }

  constructor(private pageService: PageService) { }

  ngOnInit(): void {
  }

}
