import { Component, OnInit } from '@angular/core';
import { PageService } from 'src/app/page.service';
import { Product } from 'src/app/product.model';

@Component({
  selector: 'app-search-result',
  templateUrl: './search-result.component.html',
  styleUrls: ['./search-result.component.css']
})
export class SearchResultComponent implements OnInit {

  products!: Product[];

  getProducts(){
    return this.pageService.getProducts().subscribe(products => this.products = products);
  }

  constructor(private pageService: PageService) { }

  ngOnInit(): void {
    this.getProducts();
  }

}
