import { Component, OnInit } from '@angular/core';
import { Category } from 'src/app/category.model';
import { PageService } from 'src/app/page.service';

@Component({
  selector: 'app-main-page',
  templateUrl: './main-page.component.html',
  styleUrls: ['./main-page.component.css']
})
export class MainPageComponent implements OnInit {

  title: string = "BookBuzz.com";

  categories!: Category[];

  getCategories(){
    this.pageService.getCategories().subscribe(categories => this.categories=categories);
  }

  constructor(private pageService: PageService) { }

  ngOnInit(): void {
    this.getCategories();
  }

}
