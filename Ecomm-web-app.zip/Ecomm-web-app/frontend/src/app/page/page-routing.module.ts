import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CartComponent } from './cart/cart.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { MainPageComponent } from './main-page/main-page.component';
import { SearchResultComponent } from './search-result/search-result.component';

const routes: Routes = [
  { path: 'main', component: MainPageComponent},
  { path: 'result', component: SearchResultComponent},
  { path: 'cart', component: CartComponent},
  { path: 'login', component: LoginPageComponent},
  { path: '', redirectTo:'/main', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PageRoutingModule { }
