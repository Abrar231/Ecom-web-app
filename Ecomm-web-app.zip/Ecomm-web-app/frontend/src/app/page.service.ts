import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Category } from './category.model';
import { Product } from './product.model';

@Injectable({
  providedIn: 'root'
})
export class PageService {

  private productUrl = 'api/products';
  private categoryUrl = 'api/categories';
  private cartUrl = 'api/cart';

  constructor(private http: HttpClient) { }

  getProducts(): Observable<Product[]>{
    return this.http.get<Product[]>(this.productUrl);
  }

  getCategories(): Observable<Category[]>{
    return this.http.get<Category[]>(this.categoryUrl);
  }

  getProduct(id: number): Observable<Product>{
    return this.http.get<Product>(this.productUrl + id);
  }

  getCategory(id: number): Observable<Category>{
    return this.http.get<Category>(this.categoryUrl + id);
  }

  addtoCart(product: Product){
    return this.http.post<Product>(this.cartUrl, product);
  }

  getProductsFromCart(): Observable<Product[]>{
    return this.http.get<Product[]>(this.cartUrl);
  }
}
