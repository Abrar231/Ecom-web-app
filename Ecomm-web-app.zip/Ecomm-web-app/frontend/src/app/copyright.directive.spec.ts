import { CopyrightDirective } from './copyright.directive';

describe('CopyrightDirective', () => {
  it('should create an instance', () => {
    const directive = new CopyrightDirective();
    expect(directive).toBeTruthy();
  });
});
