import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';


@Injectable({
  providedIn: 'root'
})
export class DataService implements InMemoryDbService{

  constructor() { }

  createDb(){
    const products = [
      { id: 1, name: 'Don Quixote', author: 'Miguel De Cervantes', category: 'Literature & Fiction', price: 450},
      { id: 2, name: 'Atomic Habits', author: 'James Clear', category: 'Self-Help & Education', price: 450},
      { id: 3, name: 'Sapiens: A Brief History Of Humankind', author: 'Yuval Noah Harari', category: 'History', price: 355},
      { id: 4, name: 'Rich Dad Poor Dad', author: 'Robert Kiyosaki', category: 'Finance & Business', price: 300},
      { id: 5, name: 'Harry Pottr', author: 'J K Rowling', category: 'Literature & Fiction', price: 650},
      { id: 6, name: 'Nikola Tesla: A Life From Beginning To End', author: 'Hourly History', category: 'Biographies & Autobiograhies', price: 200},
      { id: 7, name: 'Thinking Fast And Slow', author: 'Daniel Kahneman', category: 'Society & Social Sciences', price: 380},
      { id: 8, name: 'The Psychology Of Money', author: 'Morgan Housel', category: 'Finance & Business', price: 280},
      { id: 9, name: 'Wings Of Fire', author: 'A P J Abdul Kalam', category: 'Biographies & Autobiograhies', price: 280},
      { id: 10, name: 'The Alchemist', author: 'Paulo Coelho', category: 'Literature & Fiction', price: 260},
      { id: 11, name: 'Zero To One', author: 'Peter Thiel', category: 'Finance & Business', price: 450},
      { id: 12, name: 'Ikigai', author: 'Hector GArcia', category: 'Self-Help & Education', price: 500},
      { id: 13, name: 'Shoe Dog: A Memoir By The Creator Of Nike', author: 'Phil Knight', category: 'Biographies & Autobiograhies', price: 340},
      { id: 14, name: 'The Almanack Of Naval Ravikant', author: 'Eric Jorgenson', category: 'Literature & Fiction', price: 340},
      { id: 15, name: 'Tools Of Titans', author: 'Timothy Ferriss', category: 'Self-Help & Education', price: 800},
      { id: 16, name: 'The Great Gatsby', author: 'Scott Fitzgerald', category: 'Literature & Fiction', price: 100},
      { id: 17, name: 'Think Like A Monk', author: 'Jay Shetty', category: 'Society & Social Sciences', price: 320},
      { id: 18, name: 'Why I Am An Athiest And Other Works', author: 'Bhagat Singh', category: 'Biographies & Autobiograhies', price: 130},
      { id: 19, name: 'As A Man Thinketh', author: 'James Allen', category: 'Literature & Fiction', price: 60},
      { id: 20, name: '21 Lessons For 21st Century', author: 'Yuval Noah Harari', category: 'Political Theory', price: 250},
    ];
    const categories = [
      {id: 1, name: 'Literature & Fiction'},
      {id: 2, name: 'Self-Help & Education'},
      {id: 3, name: 'History'},
      {id: 4, name: 'Finance & Business'},
      {id: 5, name: 'Biographies & Autobiograhies'},
      {id: 6, name: 'Society & Social Sciences'},
      {id: 7, name: 'Political Theory'},
    ];
    const cart = [];
    return {
      products, categories
    }
  }
}
