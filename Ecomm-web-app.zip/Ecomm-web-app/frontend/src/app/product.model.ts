export interface Product {
  id: number;
  name: string;
  author: string;
  categoryName: string;
  price: number;
}
